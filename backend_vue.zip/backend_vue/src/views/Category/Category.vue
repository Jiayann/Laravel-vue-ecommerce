<template>
  <div class = "container">
      <div class="row">
          <div class="col-12 text-center">
              <h3 class="pt-3">Our Category</h3>
          </div>
      </div>
      <div class="row">
      </div>
  </div>
</template>



<script>

const axios = require("axios");
//const sweetalert = require("sweetalert");

  export default{
      
      data(){
          return{};
      },
  
      method(){

      }
      
    };
     
</script>

<style scoped>
</style>